# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Notes(Component):
    """A Notes component.
Notes allows users to add text notes and drawings to an existing dash app

Keyword arguments:
- id (string; optional): The ID used to identify this component in Dash callbacks.
- username (string; optional): The name we'll associate with any new entries added by the user.
- permission (a value equal to: 'view', 'comment', 'add', 'self', 'admin'; default 'admin'): The commenting rights of the current user.
view: only view existing notes, no changes allowed.
comment: add entries to existing text notes, but no adding new notes or
  editing or deleting notes.
add: add new and comment on existing notes, but no editing or deleting.
self: add and comment on notes, and edit or delete your own entries.
admin: edit or delete anyone's entries or notes.
- modes (a value equal to: 'draw', 'text', 'draw+text', ''; default 'draw+text'): Allowed note types, as a flag list. Values are
'draw', 'text', 'draw+text', or '' to disable / hide all notes.
- drawings (dict; optional): The drawings currently on the page. drawings has the following type: list of dicts containing keys 'anchor_id', 'points'.
Those keys have the following types:
  - anchor_id (string; optional): The component ID this shape is associated with.
If omitted, this shape will be positioned relative to the page
  - points (list of list of list of numbersss; required): The points defining this shape. Should be an array of arrays of
number pairs: [[[x, y], [x, y], ...], ...]
x=0 is the left edge of the component (or page), x=1 is the right.
y=0 is the top edge of the component (or page), y=1 is the bottom.
x/y values are mostly between 0 and 1, but can extend beyond this.
- text (dict; optional): The text notes currently on the page. text has the following type: list of dicts containing keys 'anchor_id', 'x', 'y', 'open', 'entries'.
Those keys have the following types:
  - anchor_id (string; optional): The component ID this note is associated with.
If omitted, this note will be positioned relative to the page
  - x (number; optional): The horizontal position of the note anchor, from 0 to 1.
0 is the left edge of the component (or page), 1 is the right edge.
  - y (number; optional): The vertical position of the note anchor, from 0 to 1.
0 is the top edge of the component (or page), 1 is the bottom edge.
  - open (boolean; optional): Is this note open?
  - entries (dict; optional): The text comments associated with this note. entries has the following type: list of dicts containing keys 'username', 'edit_username', 'value'.
Those keys have the following types:
  - username (string; optional): The name of the user who made this comment
  - edit_username (string; optional): The name of the user who last edited this comment, if any
  - value (string; required): The comment itself
- quick_text (list of strings; optional): Comments that can be inserted with a single click / tap.
Only empty comment boxes will show these options, not those with
existing entries.
- loading_state (dict; optional): Object that holds the loading state object coming from dash-renderer. loading_state has the following type: dict containing keys 'is_loading', 'prop_name', 'component_name'.
Those keys have the following types:
  - is_loading (boolean; optional): Determines if the component is loading or not
  - prop_name (string; optional): Holds which property is loading
  - component_name (string; optional): Holds the name of the component that is loading"""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, username=Component.UNDEFINED, permission=Component.UNDEFINED, modes=Component.UNDEFINED, drawings=Component.UNDEFINED, text=Component.UNDEFINED, quick_text=Component.UNDEFINED, loading_state=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'username', 'permission', 'modes', 'drawings', 'text', 'quick_text', 'loading_state']
        self._type = 'Notes'
        self._namespace = 'dash_notes'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'username', 'permission', 'modes', 'drawings', 'text', 'quick_text', 'loading_state']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Notes, self).__init__(**args)
