import dash_html_components as html
from . import constants
import dash
from packaging import version as version_pkg
import dash_table
try:
    from dash_design_kit import DataTable
    from dash_design_kit import __version__ as ddk_version
except ImportError:
    from dash_table import DataTable
    ddk_version = False

MAIN_CONTAINER_STYLE = {"width": "96%", "margin": "0% 2%"}


def ArchiveTable(version, store, relpath, columns=None, filter_by={}):
    if version == 2:
        if version_pkg.parse(dash.__version__) < version_pkg.parse("1.13.0"):
            raise Exception("ArchiveTable version 2 requires `dash` version 1.13.0 or greater")

        if ddk_version and version_pkg.parse(ddk_version) < version_pkg.parse("1.5.0"):
            raise Exception("ArchiveTable version 2 requires `dash_design_kit` version 1.5.0 or greater")

    if columns is None:
        columns = [
            {"id": constants.KEYS["snapshot_id"], "name": "Web Report"},
            {"id": constants.KEYS["pdf"], "name": "PDF"},
            {"id": constants.KEYS["username"], "name": "Creator"},
            {"id": constants.KEYS["created_time"], "name": "Created Date"},
        ]

    results = store._query_recent(columns, filter_by=filter_by)
    rows = []
    for result in results:
        row = {}
        for i, col in enumerate(columns):
            # If empty value, return empty string
            if result[i] is None:
                cell = ""
            else:
                cell = result[i]

            # Magic handling for special columns
            if col["id"] == constants.KEYS["snapshot_id"]:
                cell = _format_link(version, relpath, "layout-json", result, "View", "/{}")
                col["presentation"] = "markdown"
            elif col["id"] == constants.KEYS["pdf"]:
                cell = _format_link(version, relpath, "pdf", result, "Download", "/{}.pdf")
                col["presentation"] = "markdown"
            row[col["id"]] = cell
        rows.append(row)
    if version == 2:
        return _DatatableView(columns, rows)
    elif version == 1:
        return _ListView(columns, rows)


def _ListView(columns=None, rows=None):
    header = []

    for col in columns:
        header.append(html.Th(col["name"], style=col.get("style", {})))
    header = html.Tr(header)

    table_rows = []

    for row in rows:
        table_row = []
        for col in columns:
            cell = row.get(col["id"], "")
            table_row.append(html.Td(cell, style=col.get("style", {})))

        table_rows.append(html.Tr(table_row))
    return html.Table(
        className="list-view",
        style=MAIN_CONTAINER_STYLE,
        children=[html.Thead(header), html.Tbody(table_rows)],
    )


def _DatatableView(columns=None, rows=None):
    return html.Div(
        style=MAIN_CONTAINER_STYLE,
        children=[
            DataTable(
                id='datatable-paging-page-count',
                columns=columns,
                data=rows,
                page_current=0,
                page_size=15,
                filter_action="native",
                page_action="native",
                cell_selectable=False,
                style_as_list_view=True,
                style_cell={'textAlign': 'left'},
                style_header={
                    'fontWeight': 'bold',
                    'textAlign': 'left'
                },
                css=[
                    dict(selector='.cell-markdown p', rule='margin: 0;'),
                    # Until https://github.com/plotly/dash-table/issues/694 is resolved:
                    dict(selector='.dash-filter input', rule='text-align: left;')
                ],
            )]
    )


def _format_link(version, relpath, key, result, label, path):
    exists = key in result[-1]
    if exists:
        if version == 2:
            cell = "[{}]({})".format(label, relpath(path.format(result[-2])))
        elif version == 1:
            cell = html.A(label, href=relpath(path.format(result[-2])))
    else:
        if version == 2:
            cell = "Pending"
        elif version == 1:
            cell = html.Div("Pending")
    return cell
