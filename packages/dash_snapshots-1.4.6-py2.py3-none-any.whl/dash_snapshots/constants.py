KEYS = {
    # top level redis keys
    'layout-json': 'layout-json',
    'snapshot-list': 'snapshot-list',
    'migrated-snapshots': 'migrated-snapshots',
    'meta': 'meta',
    'pdf': 'pdf',
    'schema': 'schema',

    # meta data keys
    'created_time': 'created_time',
    'username': 'username',
    'snapshot_id': 'snapshot_id',
    'task_create_time': 'task_create_time',
    'task_start_time': 'task_start_time',
    'task_finish_time': 'task_finish_time'
}

SNAPSHOT_CONTEXT = "dash_snapshot_context"
