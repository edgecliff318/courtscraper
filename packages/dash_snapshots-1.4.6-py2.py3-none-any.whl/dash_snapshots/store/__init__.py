import json
import base64
import uuid
import time
import copy
import future.utils as utils

from ..helpers import get_current_username
import plotly

import redis

from .. import constants
from . import database
from sqlalchemy.orm import aliased
from sqlalchemy import and_
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import IntegrityError

SNAPSHOT_SCHEMA_VERSION = "v1"
_strings = (type(""), type(utils.bytes_to_native_str(b"")))


class Store:
    def __init__(self, app, database_url, dash_enterprise_env):
        self._id_prefix = "snapshot"

        # Make sure database dialect is supported
        database_url = database.coerce_database_url(database_url)
        self._database_url = database_url
        dialect = database.get_dialect(database_url)
        self._database_dialect = dialect
        self._is_sql_database = database.is_sql_database(database_url)

        if self._is_sql_database is False:
            self._redis = redis.Redis.from_url(
                database_url, decode_responses=True,
            )
            self._redisBinary = redis.StrictRedis.from_url(
                database_url, decode_responses=False,
            )
        else:
            app.config['SQLALCHEMY_ECHO'] = False
            app.config['SQLALCHEMY_DATABASE_URI'] = database_url
            app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

            base, self.Snapshot, self.Blob = database.get_tables(dialect, dash_enterprise_env)

            # Initialize flask_sqlalchemy
            db = SQLAlchemy(app, model_class=base)
            if self._database_dialect == "sqlite":
                database.assert_sqlite_supports_json(db.session)

            # Create tables
            try:
                db.create_all()
                db.session.commit()
            except IntegrityError:
                db.session.rollback()
            self.db = db

            # Create indexes if on POSTGRESQL
            if self._database_dialect == "postgresql":
                indexes = [
                    "CREATE INDEX IF NOT EXISTS {table_name}_jsonb__created_time_idx ON {table_name} ((meta->>'_created_time'));",
                    "CREATE INDEX IF NOT EXISTS idxgin ON {table_name} USING gin (meta);"
                ]
                for index in indexes:
                    index = index.format(table_name=self.Snapshot.__tablename__)
                    try:
                        db.session.execute(index)
                        db.session.commit()
                    except IntegrityError:
                        db.session.rollback()

            # TODO: Turn on foreign key support on SQLITE

    # SNAPSHOT
    def _meta_keys(self, snapshot_id):
        if self._is_sql_database:
            snap = self.db.session.query(self.Snapshot).filter_by(id=snapshot_id).one_or_none()
            keys = snap.meta.keys()
        else:
            keys = self._redis.hkeys(self._with_meta_namespace(snapshot_id))
        return keys

    def _meta_get(self, snapshot_id, key):
        try:
            if self._is_sql_database:
                value = self.db.session.query(self.Snapshot.meta[key]).filter_by(id=snapshot_id).one()
                value = value[0]
                if value is None:
                    raise Exception("Empty key")
            else:
                value = self._redis.hget(self._with_meta_namespace(snapshot_id), key)
        except:
            raise Exception("Error retrieving {} from {}".format(key, snapshot_id))
        try:
            if self._is_sql_database:
                return value
            else:
                return json.loads(value)
        except:
            raise Exception(
                "Error parsing {}.{} = {}".format(snapshot_id, key, value)
            )

    def _meta_update(self, snapshot_id, items_dict):
        if len(items_dict) == 0:
            return

        if self._is_sql_database:
            snap = self.db.session.query(self.Snapshot).filter_by(id=snapshot_id).one_or_none()
            if snap is None:
                # Create snapshot if it doesn't exist
                snap = self.Snapshot(id=snapshot_id, meta=items_dict)
                self.db.session.add(snap)
            else:
                # TODO: only update modified fields instead of copying/merging in Python
                meta = copy.deepcopy(snap.meta)
                meta.update(items_dict)
                snap.meta = meta
            database._commitSessionOrRollback(self.db.session)
        else:
            self._redis.hmset(
                self._with_meta_namespace(snapshot_id),
                {k: json.dumps(v) for (k, v) in items_dict.items()},
            )
            if "_created_time" in items_dict:
                self._redis.zadd(
                    constants.KEYS["snapshot-list"], {snapshot_id: items_dict["_created_time"]}
                )

    def _snapshot_exists(self, snapshot_id):
        if self._is_sql_database:
            exists = self.db.session.query(self.Snapshot.query.filter_by(id=snapshot_id).exists()).scalar()
        else:
            exists = self._redis.exists(self._with_meta_namespace(snapshot_id)) == 1
        return exists

    def _snapshot_delete(self, snapshot_id):
        if self._is_sql_database:
            self.db.session.query(self.Snapshot).filter(self.Snapshot.id == snapshot_id).delete()
            database._commitSessionOrRollback(self.db.session)
        else:
            # TODO: use Redis pipelining
            self._redis.zrem(constants.KEYS["snapshot-list"], snapshot_id)
            self._redis.delete(self._with_meta_namespace(snapshot_id), snapshot_id)

    # BLOBS
    def _get_blob(self, snapshot_id, key):
        if self._is_sql_database:
            blob = self.Blob.query.filter_by(snapshot_id=snapshot_id, key=key).one_or_none()
            if blob is None:
                return blob
            else:
                return blob.blob
        else:
            if key == constants.KEYS["pdf"]:
                try:
                    schema = self._meta_get(snapshot_id, 'schema')
                except Exception:
                    schema = 'v0'

                # For backward compatibility with v0
                if schema == 'v0':
                    snapshot_base64 = self._redis.hget(snapshot_id, constants.KEYS["pdf"])
                    if snapshot_base64 is None:
                        return snapshot_base64
                    else:
                        return base64.b64decode(snapshot_base64)

            return self._redisBinary.hget(snapshot_id, key)

    def _save_blob(self, snapshot_id, key, data):
        if self._is_sql_database:
            database.save_blob(self.db.session, self.Blob, snapshot_id, key, data)
        else:
            self._redisBinary.hmset(snapshot_id, {key: data})

    def _blob_exists(self, snapshot_id, key):
        if self._is_sql_database:
            exists = self.db.session.query(self.Blob.query.filter_by(snapshot_id=snapshot_id, key=key).exists()).scalar()
        else:
            exists = self._redis.hexists(snapshot_id, key) == 1
        return exists

    def _query_recent(self, columns, blobs=["layout-json", "pdf"], limit=-1, skip=0, filter_by={}):
        """
        Returns a list of snapshots sorted by date
         where each snapshot is represented by a list of columns values.
        The last two elements of a list representing a snapshot are special:
        - the second to last element is the snapshot id
        - the last element is a Python set with members named after existing blobs
        """

        for key, value in filter_by.items():
            if not isinstance(value, (float, int) + _strings):
                raise Exception("Unsupported type of value for filtering")

        n_blobs = len(blobs)
        if self._is_sql_database:
            blobAliases = [aliased(self.Blob, name=blob) for blob in blobs]

            def get_column(c):
                if c["id"] == "id":
                    return self.Snapshot.id
                else:
                    return self.Snapshot.meta[c["id"]]

            cols = list(map(get_column, columns))
            cols = cols + [self.Snapshot.id] + [blob.key for blob in blobAliases]
            q = self.db.session.query(self.Snapshot).with_entities(*cols)

            # Order by
            if self._database_dialect == "postgresql":
                q = q.order_by(self.Snapshot.meta["_created_time"].astext.desc())
            if self._database_dialect == "sqlite":
                q = q.order_by(self.Snapshot.meta["_created_time"].desc())

            # Check if blobs exists
            for index, b in enumerate(blobAliases):
                q = q.outerjoin(
                    b,
                    and_(
                        self.Snapshot.id == b.snapshot_id,
                        b.key == blobs[index]
                    )
                )

            # Filter by
            for key in filter_by:
                value = filter_by[key]
                field = self.Snapshot.meta[key]
                if isinstance(value, int):
                    casted_field = field.as_integer()
                elif isinstance(value, float):
                    casted_field = field.as_float()
                elif isinstance(value, _strings):
                    casted_field = field.as_string()
                q = q.filter(casted_field == value)

            # Limit the number of results
            if limit != -1:
                q = q.limit(limit)
            # Offset
            q = q.offset(skip)

            snaps = q.all()

            if n_blobs == 0:
                return [list(row) + [set()] for row in snaps]
            else:
                return [list(row[:-n_blobs]) + [set([i for i in row[-n_blobs:] if i])] for row in snaps]
        else:
            start = skip
            if limit >= 0:
                end = start + limit - 1
            else:
                end = -1

            snapshot_ids = self._redis.zrevrange(constants.KEYS["snapshot-list"], start, end)

            def get_column(c):
                if c["id"] == "id":
                    return "snapshot_id"
                else:
                    return c["id"]

            # retrieve column to filter_by
            filter_cols = [key for key in filter_by]

            cols = filter_cols + list(map(get_column, columns)) + ["snapshot_id"]
            pipe = self._redis.pipeline()
            for snapshot_id in snapshot_ids:
                pipe.hmget(self._with_meta_namespace(snapshot_id), *cols)
                for blob_key in blobs:
                    pipe.hexists(snapshot_id, blob_key)
            result = pipe.execute()

            rows = []
            # Group results by snapshot
            for grouped_result in zip(*[iter(result)] * (1 + n_blobs)):
                # Parse metadata
                parsed = [None if x is None else json.loads(x) for x in grouped_result[0]]

                # Filter out rows not matching requested values
                if False in [filter_by[key] == parsed[i] for i, key in enumerate(filter_cols)]:
                    continue

                # Remove filter_col from result
                parsed = parsed[len(filter_cols):]

                # Find blobs that exist and add it to a set
                s = set([])
                for index, exists in enumerate(grouped_result[1:]):
                    if exists:
                        s.add(blobs[index])
                rows.append(parsed + [s])
            return rows

    # HELPERS
    def _with_meta_namespace(self, snapshot_id):
        return "{}.{}".format(snapshot_id, constants.KEYS["meta"])

    # TODO - Keep this as part of the public api to allow
    # users to override it?
    # TODO - Use https://github.com/brainix/pottery#nextid?
    def _generate_snapshot_id(self):
        now_seconds = int(time.time())
        return "{}-{}-{}".format(
            self._id_prefix, str(now_seconds), str(uuid.uuid4()).split("-")[0]
        )

    def _snapshot_save_init(self):
        snapshot_id = self._generate_snapshot_id()
        created_time_seconds = time.time()
        created_time_formatted = time.strftime("%Y-%m-%d %X")

        username = get_current_username()

        self._meta_update(
            snapshot_id,
            {
                constants.KEYS["username"]: username,
                constants.KEYS["snapshot_id"]: snapshot_id,
                constants.KEYS["schema"]: SNAPSHOT_SCHEMA_VERSION,
                constants.KEYS["created_time"]: created_time_formatted,
                "_created_time": created_time_seconds  # gets indexed in meta_update
            },
        )

        return (snapshot_id, created_time_formatted)

    def _save_component_tree(self, snapshot_id, component_tree):
        data = json.dumps(
            component_tree, cls=plotly.utils.PlotlyJSONEncoder
        )
        self._save_blob(snapshot_id, constants.KEYS["layout-json"], data)

    def _snapshot_async_init(self):
        (snapshot_id, created_time_formatted) = self._snapshot_save_init()
        self._meta_update(
            snapshot_id,
            {
                constants.KEYS["task_create_time"]: created_time_formatted,
                constants.KEYS["task_start_time"]: "-",
                constants.KEYS["task_finish_time"]: "-",
            },
        )

        return snapshot_id
